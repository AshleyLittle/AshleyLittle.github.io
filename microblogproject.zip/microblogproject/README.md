Ashley Little
littl475
5314728
CSCI 4131

Microblog created by following Miguel Grinberg's Flask Tutorial (parts 1-9 and 11).
https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-i-hello-world